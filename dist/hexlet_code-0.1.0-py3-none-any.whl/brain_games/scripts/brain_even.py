#!/usr/bin/env python
from brain_games.tests import test_1


def main():
    test_1()


if __name__ == '__main__':
    main()
