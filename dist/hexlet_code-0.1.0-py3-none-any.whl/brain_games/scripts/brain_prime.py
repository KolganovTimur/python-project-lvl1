#!/usr/bin/env python
from brain_games.games.prime import start


def main():
    start()


if __name__ == '__main__':
    main()
