#!/usr/bin/env python
from brain_games.games.engine import base
from brain_games.games import calc


def main():
    base(calc)


if __name__ == '__main__':
    main()
