#!/usr/bin/env python
from brain_games.games.engine import base
from brain_games.games import prime


def main():
    base(prime)


if __name__ == '__main__':
    main()
