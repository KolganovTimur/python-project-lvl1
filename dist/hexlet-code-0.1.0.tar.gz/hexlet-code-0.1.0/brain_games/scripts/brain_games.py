#!/usr/bin/env python
from brain_games.cli import greeting


def main():
    greeting()


if __name__ == '__main__':
    main()
